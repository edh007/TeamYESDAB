#pragma once

namespace gi
{
  class Event
  {
  public:
    enum class Type
    {
      EVENT_TOUCH,
      EVENT_KEYBOARD,
      EVENT_ACCELERATION,
      EVENT_MOUSE,
      EVENT_FOCUS,
      EVENT_GAME_CONTROLLER,
      EVENT_CUSTOM
    };

    Event(Type type);
    ~Event();

    Type GetType() const
    {
      return m_type;
    }

    void StopPropagation()
    {
      m_isStopped = true;
    }

    Type m_type;
    bool m_isStopped;

  };
}