#pragma once

namespace gi
{
  class Message
  {
  public:
    Message();
    ~Message();

    enum class MessageType
    {
      INIT_PROGRAM,
      UPDATE_PROGRAM,
      EXIT_PROGRAM,

      COLLISION,
      DRAW,

      // Keyboard Input
      KEY_W,
      KEY_A,
      KEY_S,
      KEY_D
    };
  };
}