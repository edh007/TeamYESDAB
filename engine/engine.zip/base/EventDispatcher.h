#pragma once

#include "EventListener.h"

namespace gi
{
  class EventDispatcher
  {
  public:
    bool AddListener(EventListener* pListener);
    bool RemoveListener(EventListener* pListener);

  protected:
    virtual void DispatchEvent();

    std::vector<EventListener*> m_listeners;
  };
}