#pragma once

#include "EventListener.h"

namespace gi
{
  class KeyboardEventListener : public EventListener
  {
  public:
    KeyboardEventListener() {}
    ~KeyboardEventListener() {}

    void handleEvent()
    {

    }

    void handleEvent(int id)
    {

    }

  protected:

  };
}
