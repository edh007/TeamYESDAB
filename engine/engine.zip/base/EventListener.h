#pragma once

#include <functional>
#include <unordered_map>
#include <SDL.h>

typedef void (SubscriptionFunction(void* eventData));
typedef bool (CallingConditionFunction(double eventID));

namespace gi
{
  class EventListener
  {
  public:
    EventListener() {}
    ~EventListener() {}

    virtual void handleEvent() {}
    virtual void handleEvent(int id) {}

  private:

    std::function<SubscriptionFunction>     m_method;
    std::function<CallingConditionFunction> m_callingCondition;

    // Sample Usage
    /*
    this->updateSubscriber = new Subscriber(this);
    updateSubscriber->method = std::bind(&Game::Update, this, std::placeholders::_1);
    Dispatcher::AddSpecificEventSubscriber(updateSubscriber, EVENT_KEYBOARD);
    */

    void*  m_pOwner;
    double m_eventID;
  };
}