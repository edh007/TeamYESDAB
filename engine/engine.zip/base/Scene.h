#pragma once

namespace gi
{
	class Scene
	{
	public:
		virtual ~Scene() {}

		virtual void Load() {}
		virtual void Init() {}
		virtual void Update(float) {}
		virtual void Shutdown() {}
		virtual void Unload() {}
	};
}
