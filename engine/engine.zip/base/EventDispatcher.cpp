#include "EventDispatcher.h"

namespace gi
{
  bool EventDispatcher::AddListener(EventListener* pListener)
  {
    std::vector<EventListener*>::iterator it = find(m_listeners.begin(), m_listeners.end(), pListener);
    if (it != m_listeners.end())
      return false;

    m_listeners.push_back(pListener);
    return true;
  }

  bool EventDispatcher::RemoveListener(EventListener* pListener)
  {
    std::vector<EventListener*>::iterator it = find(m_listeners.begin(), m_listeners.end(), pListener);
    
    if (it == m_listeners.end())
      return false;

    m_listeners.erase(it);
    return true;
  }

  void EventDispatcher::DispatchEvent()
  {
    for (std::vector<EventListener*>::iterator it = m_listeners.begin(); it != m_listeners.end(); ++it)
    {
      (*it)->handleEvent();
    }
  }
}