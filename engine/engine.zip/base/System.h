#pragma once

#include <map>

#include "base/Message.h"
#include "Engine.h"

namespace gi
{
  class System
  {
  public:

    explicit System(Engine* pGameEngine)
      : m_pEngine(pGameEngine)
    {
    }
    virtual ~System() = 0;

    virtual void Initialize() = 0;
    virtual void Update() = 0;
    virtual void Shutdown() = 0;
    virtual void SendMsg(void* data1, void* data2, Message msg) = 0;

  private:
    Engine* m_pEngine;

    //std::unordered_map<Entity*> m_entityMap;
  };
}