#include "base\Event.h"

namespace gi
{
  Event::Event(Type type)
    : m_type(type), m_isStopped(false)
  {

  }

  Event::~Event()
  {

  }

  Event::Type Event::GetType() const
  {
    return m_type;
  }

  void Event::StopPropagation()
  {
    m_isStopped = true;
  }
}