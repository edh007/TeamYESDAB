#pragma once

namespace gi
{
  class Node
  {
  public:
    Node();
    ~Node();


  };
}