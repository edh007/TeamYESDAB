#pragma once

class Entity
{
public:
  Entity();
  ~Entity();

  // void RegisterComponent(Component);
  // GetComponent();
  // DeleteComponent();

private:
  
};