#include "SceneHandler.h"

gi::Scene* gi::SceneHandler::GetCurrScene()
{
	return m_pCurrScene;
}

void gi::SceneHandler::StartScene(Scene* pScene)
{
	m_pCurrScene = pScene;
	// TODO(JIN) : Need to shutdown and delete
}

void gi::SceneHandler::PushScene(Scene* pScene)
{
	m_scenes.push_back(pScene);
	m_pNextScene = pScene;
}

void gi::SceneHandler::PopScene()
{

	//DEBUG_ASSERT(_pCurrScene == nullptr, "current scene shouldn't be null pointer\n");

	m_scenes.pop_back();

	if (m_scenes.size() == 0)
	{
		// TODO (JIN) : Shutdown system and quit window
	}
	//else
}

void gi::SceneHandler::SetNextScene(Scene* pScene)
{

	pScene;
}

void gi::SceneHandler::ReplaceScene(Scene* pScene)
{
	pScene;
}

gi::SceneHandler::SceneHandler()
{
}

gi::SceneHandler::~SceneHandler()
{
}
