#include "Engine.h"

#include "framework\Application.h"
#include "graphics\Renderer.h"
#include "framework\Input.h"
#include "framework\Timer.h"

// TODO(JIN) : Test for timer
#include <Windows.h>
#include "framework\Debug.h"

namespace gi
{
	Engine* g_pEngine = nullptr;

	// public member functions
	Engine::Engine()
		: m_quit(false)
	{
		// DebugAssert if g_pEngine is not nullptr
    assert(g_pEngine == nullptr);
		g_pEngine = this;

	}

	Engine::~Engine()
	{
		
	}

	void Engine::Run()
	{
		Initialize();

		m_pFrameHandler->Start();
		float dt = m_pFrameHandler->GetElapsedSec();

		while(!m_quit)
		{
            
			// Handle all the events from the SDL
			ProcessEvents();

			// Update

			// Draw

      m_pRenderer->Update();


			// TODO(JIN) : Test code for input
			if (m_pInput->IsKeyTriggered(SDL_SCANCODE_0))
			{
				m_quit = true;
			}
			if(m_pInput->IsKeyPressed(SDL_SCANCODE_LALT) 
				&& m_pInput->IsKeyPressed(SDL_SCANCODE_1))
			{
				m_quit = true;				
			}

			// Draw

			dt = m_pFrameHandler->GetElapsedSec();
			m_pFrameHandler->Start();			
		}

		Shutdown();
	}

	void Engine::Quit()
	{
		m_quit = true;
	}

	// private member functions
	void Engine::Initialize()
	{
    
    m_systemVector.push_back(new Application(this));
    m_systemVector.push_back(new Renderer(this));
    m_systemVector.push_back(new Input(this));
    m_systemVector.push_back(new Timer(this));


		// Initialize App System
		m_pApp = new Application(this);
		m_pApp->Initialize();

    m_pRenderer = new Renderer;
    m_pRenderer->Initialize(m_pApp->GetWindow());

		// Initialize Input Framework
		m_pInput = new Input;
		m_pInput->Initialize();

		// TODO(JIN) : Test for frame
		// Initialize Frame System
		m_pFrameHandler = new Timer;
		//m_pFrameHandler->Initialize();

    for (auto it : m_systemVector)
    {
      it->Initialize();
    }


	}
	void Engine::Shutdown()
	{
		// Shutdown App System
		m_pApp->Shutdown();
		delete m_pApp;
		m_pApp = nullptr;

    m_pRenderer->Shutdown();
    delete m_pRenderer;
    m_pRenderer = nullptr;

		// Shutdown Input Framework
		m_pInput->Shutdown();
		delete m_pInput;
		m_pInput = nullptr;

		// TODO(JIN) : Test for frame
		// Shutdown Frame System
		//m_pFrameHandler->Shutdown();
		delete m_pFrameHandler;
		m_pFrameHandler = nullptr;
	}

	void Engine::ProcessEvents()
	{
		while (SDL_PollEvent(&m_event))
		{
			// Window Event
			if(m_event.type >= 0x200 /*SDL_WINDOWEVENT*/ && m_event.type < 0x300 /*SDL_KEYUP*/)
			{
				m_pApp->ReceiveEvent(m_event);
			}
			else if(m_event.type >= 0x300 /*SDL_KEYDOWN*/ && m_event.type < 0x900 /*SDL_CLIPBOARDUPDATE*/)
			{
				//m_pInputHandler->ReceiveEvent(m_event);
			}
		}
		m_pInput->ReceiveEvent(m_event);
	}
}









#if 0
long perfCountFrequency;

LARGE_INTEGER Win32GetWallClock()
{
	LARGE_INTEGER endCounter;
	QueryPerformanceCounter(&endCounter);
	return endCounter;
}

float Win32GetSecondsElapsed(LARGE_INTEGER start, LARGE_INTEGER end)
{
	// secondsElapsedForWork
	return (end.QuadPart - start.QuadPart) / perfCountFrequency;
}


void Engine::Run()
{
	// TODO(JIN) : How do we realiably query on this on Windows?
	LARGE_INTEGER perfCountFrequencyResult;
	QueryPerformanceFrequency(&perfCountFrequencyResult);
	perfCountFrequency = perfCountFrequencyResult.QuadPart;

	int monitorRefreshHz = 60;
	int gameUpdateHz = monitorRefreshHz / 2;
	float targetSecondsPerFram = 1.0f / (float)monitorRefreshHz;;


	Initialize();
	LARGE_INTEGER lastCounter = Win32GetWallClock();
	unsigned long lastCycleCount = __rdtsc();

	while (!m_quit)
	{
		// Handle all the events from the SDL
		ProcessEvents();

		// Update

		// Draw

		LARGE_INTEGER workCounter = Win32GetWallClock();
		float worksecondsElapsedForWork = Win32GetSecondsElapsed(lastCounter, workCounter);


		float secondsElapsedForFrame = worksecondsElapsedForWork;

		while (secondsElapsedForFrame < targetSecondsPerFram)
		{

			secondsElapsedForFrame = Win32GetSecondsElapsed(lastCounter, Win32GetWallClock());
		}

#if 0
		float msPerFrame = ((1000.0f * (float)counterElapsed / (float)perfCountFrequency)) *;
		float fps = (float)perfCountFrequency / (float)counterElapsed;
		float mcPerFrame = ((float)cyclesElapsed / (1000.0f * 1000.0f));
#endif
		LARGE_INTEGER endCounter = Win32GetWallClock();
		lastCounter = endCounter;

		unsigned long endCycleCount = __rdtsc();
		unsigned long cyclesElapsed = endCycleCount - lastCycleCount;
		lastCycleCount = endCycleCount;


	}

	Shutdown();
}
#endif