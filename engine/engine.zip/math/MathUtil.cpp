#include "MathUtil.h"

float DegreeToRadian(float degree)
{
	return degree * 0.01745329251f/*pi / 180.f*/;
}

float RadianToDegree(float radian)
{
	return radian * 57.2957795131f/*180.f / pi*/;
}

Mat4 GetTranslation(float x, float y, float z)
{
	Mat4 rst;
	rst.Translate(x, y, z);
	return rst;
}

Mat4 GetRotation(float x, float y, float z, float radian)
{
	Mat4 rst;
	rst.Rotate(x, y, z, radian);
	return rst;
}

Mat4 GetRotationX(float rad)
{
	Mat4 rst;
	rst.RotateX(rad);
	return rst;
}

Mat4 GetRotationY(float rad)
{
	Mat4 rst;
	rst.RotateY(rad);
	return rst;
}

Mat4 GetRotationZ(float rad)
{
	Mat4 rst;
	rst.RotateZ(rad);
	return rst;
}

Mat4 GetScaling(float x, float y, float z)
{
	Mat4 rst;
	rst.Scale(x, y, z);
	return rst;
}

Mat4 GetTransform(const Mat4& translation, const Mat4& rotation, const Mat4& scaling)
{
	Mat4 rst;
	rst.Transform(translation, rotation, scaling);
	return rst;
}
