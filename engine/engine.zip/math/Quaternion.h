#pragma once

class Quaternion
{
	
};