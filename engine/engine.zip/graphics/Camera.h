#pragma once
#include "../math/Math.h"
#include <cmath>

const float YAW = -90.0f;
const float PITCH = 0.0f;
const float SPEED = 2.5f;
const float SENSITIVTY = 0.1f;
const float ZOOM = 45.0f;

struct Camera
{
    //Camera Attributes
    Vec3 pos;
    Vec3 front;
    Vec3 up;
    Vec3 right;
    Vec3 worldUp;

    //Angle
    float yaw;
    float pitch;

    //Options
    float zoom;
    float MovementSpeed;
    float MouseSensitivity;

	Mat4 LookAt(Vec3 eye, Vec3 center, Vec3 up);
	// Returns the view matrix calculated using Eular Angles and the LookAt Matrix
	
    // Constructor with vectors
    Camera(Vec3 _position = Vec3(0.0f, 0.0f, 0.0f), Vec3 _up = Vec3(0.0f, 1.0f, 0.0f), float _yaw = YAW, float _pitch = PITCH) : front(Vec3(0.0f, 0.0f, -1.0f)), MovementSpeed(SPEED), MouseSensitivity(SENSITIVTY), zoom(ZOOM)
    {
        pos = _position;
        worldUp = _up;
        yaw = _yaw;
        pitch = _pitch;
        updateCameraVectors();
    }

	Mat4 GetViewMatrix()
	{
		return LookAt(pos, pos + front, up);
		//return LookAt(pos, front, up);
	}

private:
    void updateCameraVectors()
    {
        // Calculate the new Front vector
        front.x = cos(DegreeToRadian(yaw)) * cos(DegreeToRadian(pitch));
        front.y = sin(DegreeToRadian(pitch));
        front.z = sin(DegreeToRadian(yaw)) * cos(DegreeToRadian(pitch));
        front.Normalize();
        // Also re-calculate the Right and Up vector
        right = (front.CrossProduct(worldUp)).Normalize(); 
        // Normalize the vectors, because their length gets closer to 0 the more you look up or down which results in slower movement.
        up = (right.CrossProduct(front)).Normalize();
    }
};
