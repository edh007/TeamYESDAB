#pragma once

#include "glew.h"
#include "../math/Math.h"
#include "ShaderManager.h"
#include "Camera.h"
#include <SDL.h>
#include <vector>
#include "Model.h"
#include <Windows.h>
#include "base/System.h"

typedef std::vector<Model*> ModelList;

namespace gi {

  class Renderer : public System {

  public:
    Renderer(Engine* pGameEngine);
    ~Renderer(void);

    void Initialize(/*SDL_Window* _pWindow*/);
    void Update();
    void Shutdown(void);

    void SetCamera(Camera _cam);
    Camera GetCamera();

    void AddModel(Model* _pModel);

    Mat4 Perspective(float const & fovy, float const & aspect, float const & zNear, float const & zFar);
    Mat4 Ortho(float const & left, float const & right, float const& bottom, float const& top, float const & zNear, float const & zFar);


  private:
    void MVP(Model* _pModel); //Calculate MVP and sent to shader
    void DrawModel(Model* _pModel); //Draw Model
    void DrawLight(); //Draw Light

    Camera m_camera;
    SDL_Window* m_pWindow;
    SDL_GLContext m_context;

    ModelList m_modelList;
    ShaderManager* m_pShader;

  };
}
