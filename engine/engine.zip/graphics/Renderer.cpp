#include "Renderer.h"
#include <cstdio>

using namespace gi;

Renderer::Renderer(Engine* pGameEngine) : System(pGameEngine)
{
	m_camera.pos = Vec3(0.f, 0.f, 3.f);
	//m_camera.front = Vec3(0, 0, 0.f);
	//m_camera.up = Vec3(0.f, 1.f, 0.f);
}

Renderer::~Renderer()
{
	delete m_pShader;
}

void Renderer::Initialize(/*SDL_Window* _pWindow*/)
{
    m_pWindow = _pWindow;
    //m_pRB = new RenderBase();
	
    // create opengl context and attach it to window
    m_context = SDL_GL_CreateContext(m_pWindow);

    // PROFILE_CORE gives the newer version, dprecated functions are disabled
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);

    // Set OpenGL version 3.3
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);

    // Turn on double buffering with a 24bit Z buffer
    // TODO(Dongho) : Maybe need to change this to 16 or 32 for system.
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);

    // Buffer swap syncronized with the monitor's vertical refresh.
    SDL_GL_SetSwapInterval(1);
    
    //Before using shader, initialize glew.
    if (glewInit() != GLEW_OK) {
        fprintf(stderr, "Failed to initialize GLEW\n");
        return;
    }
    char working_directory[MAX_PATH + 1];
    GetCurrentDirectoryA(sizeof(working_directory), working_directory); // **** win32 specific ****
    std::cout << working_directory << std::endl;
    
    //TODO(DONGHO) : TEST
    //Model* b = new Model("../../resources/obj/nanosuit/nanosuit.obj");
    //b->pos.x = 0.f;
    //b->pos.y = -1.75f;
    //b->pos.z = 0.f;
    //b->scl.x = 0.2f;
    //b->scl.y = 0.2f;
    //b->scl.z = 0.2f;
    //AddModel(b);

    Model* a = new Model(ModelType::CUBE);
	a->pos.x = 1.f;
	a->pos.y = 0.f;
	a->pos.z = 3.f;
    a->scl.x = 1.f;
    a->scl.y = 1.f;
    a->scl.z = 1.f;
    a->color.x = 1.f;
    a->color.y = 1.f;
    a->color.z = 1.f;
    a->color.w = 1.f;
	AddModel(a);
    
	m_pShader = new ShaderManager();
	m_pShader->RegisterShader("EXAMPLE", "../../resources/shader/model_loading_v.glsl", "../../resources/shader/model_loading_f.glsl");
}

void Renderer::Update()
{
    glClearColor(0.05f, 0.05f, 0.05f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	for (auto it = m_modelList.begin(); it != m_modelList.end(); ++it)
	{
		MVP(*it);
		DrawModel(*it);
	}

    // Swap window
    SDL_GL_SwapWindow(m_pWindow);
}

void Renderer::Shutdown()
{
    // Delete OpenGL context
    SDL_GL_DeleteContext(m_context);
}

void Renderer::SetCamera(Camera _cam)
{
    m_camera = _cam;
}

Camera Renderer::GetCamera()
{
    return m_camera;
}

void Renderer::MVP(Model* _pModel)
{
	Shader* ourShader = m_pShader->GetShader("EXAMPLE");
	// don't forget to enable shader before setting uniforms
	ourShader->Use();

	// render the loaded model
	Mat4 model;
	Mat4 t;
	Mat4 s;
	Mat4 r;
	t.Translate(_pModel->pos); // translate it down so it's at the center of the scene
	s.Scale(_pModel->scl);	// it's a bit too big for our scene, so scale it down
	r.Rotate(Vec3(), 0.f);

	model.Transform(t, s, r);
    //model.Transpose();
	ourShader->SetMat4("model", model);
	// view/projection transformations
	Mat4 view = m_camera.GetViewMatrix();
    //view.Transpose();
    ourShader->SetMat4("view", view);

	int w, h;
	SDL_GetWindowSize(m_pWindow, &w, &h);
	Mat4 projection = Perspective(DegreeToRadian(m_camera.zoom), (float)w / (float)h, 0.1f, 100.0f);
    //projection.Transpose();
	ourShader->SetMat4("projection", projection);
    ourShader->SetVec4("color", _pModel->color);
    ourShader->SetInt("modeltype", _pModel->m_modelType);
}

void Renderer::DrawModel(Model* _pModel)
{

	_pModel->Draw(*m_pShader->GetShader("EXAMPLE"));
}

void Renderer::DrawLight()
{
}

void Renderer::AddModel(Model* _pModel)
{
	m_modelList.emplace_back(_pModel);
}

Mat4 Renderer::Perspective(float const & fovy, float const & aspect, float const & zNear, float const & zFar)
{
	float tanHalfFovy = tan(fovy / static_cast<float>(2));

	Mat4 Result;
	Result.SetZero();

	Result.m[0][0] = (1.f) / (aspect * tanHalfFovy);
	Result.m[1][1] = (1.f) / (tanHalfFovy);
	Result.m[2][2] = -(zFar + zNear) / (zFar - zNear);
	Result.m[2][3] = -(1.f);
	Result.m[3][2] = -((2.f) * zFar * zNear) / (zFar - zNear);
	return Result;
}

Mat4 Renderer::Ortho(float const & left, float const & right, float const & bottom, float const & top, float const & zNear, float const & zFar)
{
	Mat4 Result;
	Result.m[0][0] = (2.f) / (right - left);
	Result.m[1][1] = (2.f) / (top - bottom);
	Result.m[2][2] = (2.f) / (zFar - zNear);
	Result.m[3][0] = (-(right + left)) / (right - left);
	Result.m[3][1] = (-(top + bottom)) / (top - bottom);
	Result.m[3][2] = (-(zFar + zNear)) / (zFar - zNear);
	Result.m[3][3] = (1.f);
	return Result;
}

//TODO(DONGHO) : Modify operator when compile graphics
//Mat4 Mat4::operator*(const Mat4& rhs) const
//{
//    Mat4 result;
//
//    result.m[0][0] = m[0][0] * rhs.m[0][0] + m[0][1] * rhs.m[1][0] + m[0][2] * rhs.m[2][0] + m[0][3] * rhs.m[3][0];
//    result.m[0][1] = m[0][0] * rhs.m[0][1] + m[0][1] * rhs.m[1][1] + m[0][2] * rhs.m[2][1] + m[0][3] * rhs.m[3][1];
//    result.m[0][2] = m[0][0] * rhs.m[0][2] + m[0][1] * rhs.m[1][2] + m[0][2] * rhs.m[2][2] + m[0][3] * rhs.m[3][2];
//    result.m[0][3] = m[0][0] * rhs.m[0][3] + m[0][1] * rhs.m[1][3] + m[0][2] * rhs.m[2][3] + m[0][3] * rhs.m[3][3];
//
//    result.m[1][0] = m[1][0] * rhs.m[0][0] + m[1][1] * rhs.m[1][0] + m[1][2] * rhs.m[2][0] + m[1][3] * rhs.m[3][0];
//    result.m[1][1] = m[1][0] * rhs.m[0][1] + m[1][1] * rhs.m[1][1] + m[1][2] * rhs.m[2][1] + m[1][3] * rhs.m[3][1];
//    result.m[1][2] = m[1][0] * rhs.m[0][2] + m[1][1] * rhs.m[1][2] + m[1][2] * rhs.m[2][2] + m[1][3] * rhs.m[3][2];
//    result.m[1][3] = m[1][0] * rhs.m[0][3] + m[1][1] * rhs.m[1][3] + m[1][2] * rhs.m[2][3] + m[1][3] * rhs.m[3][3];
//
//    result.m[2][0] = m[2][0] * rhs.m[0][0] + m[2][1] * rhs.m[1][0] + m[2][2] * rhs.m[2][0] + m[2][3] * rhs.m[3][0];
//    result.m[2][1] = m[2][0] * rhs.m[0][1] + m[2][1] * rhs.m[1][1] + m[2][2] * rhs.m[2][1] + m[2][3] * rhs.m[3][1];
//    result.m[2][2] = m[2][0] * rhs.m[0][2] + m[2][1] * rhs.m[1][2] + m[2][2] * rhs.m[2][2] + m[2][3] * rhs.m[3][2];
//    result.m[2][3] = m[2][0] * rhs.m[0][3] + m[2][1] * rhs.m[1][3] + m[2][2] * rhs.m[2][3] + m[2][3] * rhs.m[3][3];
//
//    result.m[3][0] = m[3][0] * rhs.m[0][0] + m[3][1] * rhs.m[1][0] + m[3][2] * rhs.m[2][0] + m[3][3] * rhs.m[3][0];
//    result.m[3][1] = m[3][0] * rhs.m[0][1] + m[3][1] * rhs.m[1][1] + m[3][2] * rhs.m[2][1] + m[3][3] * rhs.m[3][1];
//    result.m[3][2] = m[3][0] * rhs.m[0][2] + m[3][1] * rhs.m[1][2] + m[3][2] * rhs.m[2][2] + m[3][3] * rhs.m[3][2];
//    result.m[3][3] = m[3][0] * rhs.m[0][3] + m[3][1] * rhs.m[1][3] + m[3][2] * rhs.m[2][3] + m[3][3] * rhs.m[3][3];
//
//    return result;
//}