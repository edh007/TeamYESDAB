#pragma once

#define SDL_MAIN_HANDLED
#include "SDL.h"
#include "base/System.h"

#include <vector>

namespace gi
{
	class Application;
  class Renderer;
	class Timer;
	class Input;

	class Engine
	{
	public:
		Engine();
		~Engine();

		void Run();
		void Quit();
    /*
    void SendMsg(msg, entity1, entity2)
    {
      for()
      it->handle
    }*/


	private:
		void Initialize();
		void Shutdown();

		void ProcessEvents();

		bool m_quit;
		SDL_Event m_event;

		/*Application* m_pApp;
    Renderer*    m_pRenderer;
		Input*       m_pInput;
		Timer*       m_pFrameHandler;*/

    std::vector<System*> m_systemVector;
	};

	extern Engine* g_pEngine;
}