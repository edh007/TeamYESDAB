#pragma once

#include  "SDL.h"
#include "base/System.h"

namespace gi
{

	class Application : public System
	{
	public:
		void ChangeWindowSize(unsigned w, unsigned h);
		void ToggleFullScreen();

		// TODO(JIN) : Change return value to Vec2(width, height)
		unsigned GetWindowWidth() const;
		unsigned GetWindowHeight() const;

		bool CheckFullScreen() const;

    SDL_Window* GetWindow() { return m_pWindow; }
	private:		
    Application(Engine* pGameEngine);
    ~Application();

    void Initialize();
    void Update();
    void Shutdown();
    void SendMsg(void* data1, void* data2, Message msg);		

		void ReceiveEvent(const SDL_Event& event);

		// member variable
		bool m_isFullscreen;

		unsigned m_wndWidth;
		unsigned m_wndHeight;

		SDL_Window* m_pWindow;

		friend class Engine;
	};

};