#pragma once

// TODO(JIN) : Precompiled
#include <Windows.h>
#include <SDL.h>

namespace gi
{
	class Timer
	{
	public:
		Timer();
		~Timer();

		void Start();
		void Stop();

		float GetElapsedSec();
		float GetElapsedMlSec();
		float GetElapsedTimeMcSec();

#if 0 
		int GetWindowRefreshRate(SDL_Window* pWnd);
		float GetSecondsElapsed(long lastCounter, long currCounter);

		void CapFrameRate();
#endif
	private:
		bool m_isStopped;
		float m_frequency;

		Uint64 m_currCount;
		Uint64 m_lastCount;
#if 0
		int m_monitorRefreshHz;
		int m_gameUpdateHz;
		float m_targetSecondsPerFrame;
#endif
	};
}