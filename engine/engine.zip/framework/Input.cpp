#include "Input.h"

namespace gi
{
	bool Input::IsKeyTriggered(SDL_Scancode key) const
	{
		return m_currKeyboardInputs[key] && !m_prevKeyboardInputs[key];
	}
	bool Input::IsKeyPressed(SDL_Scancode key) const
	{
		return m_currKeyboardInputs[key] && m_prevKeyboardInputs;
	}
	bool Input::IsKeyReleased(SDL_Scancode key) const
	{
		return !m_currKeyboardInputs[key] && m_prevKeyboardInputs;
	}

	bool Input::IsMouseTriggered(unsigned key) const
	{
		return m_currMouseInputs[key] && !m_prevMouseInputs[key];
	}

	bool Input::IsMousePressed(unsigned key)const
	{
		return m_currMouseInputs[key] && m_prevMouseInputs[key];
	}

	bool Input::IsMouseReleased(unsigned key) const
	{
		return !m_currMouseInputs[key] && m_prevMouseInputs[key];
	}

	Input::Input()
		: m_mousePosX(0), m_mousePosY(0), m_maxKeyNum(0),
	m_prevKeyboardInputs(nullptr), m_currKeyboardInputs(nullptr)
	{

	}
	Input::~Input()
	{

	}


	void Input::Initialize()
	{
		// https://www.gamedev.net/forums/topic/441780-sdl_getkeystate-and-sdl_pumpevents/
		SDL_PumpEvents();

		m_currKeyboardInputs = const_cast<Uint8*>(SDL_GetKeyboardState(&m_maxKeyNum));
		m_prevKeyboardInputs = new Uint8[m_maxKeyNum];
		
		//std::memcpy(m_prevKeyboardInputs, m_currKeyboardInputs, sizeof(Uint8) * m_maxKeyNum);
	}
	void Input::Shutdown()
	{
		delete[] m_prevKeyboardInputs;
		m_prevKeyboardInputs = nullptr;
		m_currKeyboardInputs = nullptr;
	}
	void Input::ReceiveEvent(const SDL_Event& event)
	{
		event;
		std::memcpy(m_prevKeyboardInputs, m_currKeyboardInputs, sizeof(Uint8) * m_maxKeyNum);
		SDL_PumpEvents();

		// Update keyboard inputs
		m_currKeyboardInputs = const_cast<Uint8*>(SDL_GetKeyboardState(nullptr));

		// Gets mouse location
		Uint32 currMouseState = SDL_GetMouseState(&m_mousePosX, &m_mousePosY);

		for (unsigned i = SDL_BUTTON_LEFT; i <= SDL_BUTTON_RIGHT/*SDL_BUTTON_X2*/; ++i)
		{
			m_currMouseInputs[i - 1] = static_cast<bool>(currMouseState & SDL_BUTTON(i));
		}
	}
}