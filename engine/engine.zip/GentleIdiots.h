#pragma once

#include "Engine.h"

#include "math\Math.h"

// Framework
#include "framework\Debug.h"
#include "framework\Macros.h"
#include "framework\Application.h"
#include "framework\Timer.h"

// Base
#include "base\Scene.h"
#include "base\SceneHandler.h"